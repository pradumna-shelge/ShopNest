// new keyword

// function createuser(firstName,age){
//     this.firstName=firstName;
//     this.age=age;
// }
// const user1=new createuser("Pratik",6)

// 1.empty object this={};
// 2.return this
// 3. Object.create(createuser.prototype);

function createuser(firstName,lastNAme,email,age){
    // let user=Object.create(createuser.prototype);
    this.firstName=firstName;
    this.lastNAme=lastNAme;
    this.email=email;
    this.age=age;
}
createuser.prototype.about=function(){
   return `${this.firstName} and ${this.lastNAme}`
},
createuser.prototype.is18=function(){
   return this.age>=18;
}

let value1= new createuser("pratik","shelage","pratik@gmail.com",20);
let value3= new createuser("Sham","shelage","pratik@gmail.com",18);
let value2= new createuser("om","sss","om@gmail",9)


console.log(value2.is18());

// ager sirf createuser ki keys chagiye prototyepe ke nahi to
for (let key in value1){
    if (value1.hasOwnProperty(key)){
        console.log(key);
    }
}