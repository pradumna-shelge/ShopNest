class animal {
       constructor(name,age){
            this.name=name;
            this.age=age;
       }
       eat(){
          return `animal name is ${this.name} and age is ${this.age} ,its eat the meat`
       }
       isSuperCute(){
        return this.age<10;
       }
}

let data1=new animal ("tiger","68");
let data2=new animal ("lion","60");

console.log(data2.eat());

class dog extends animal {
  constructor(name,age,speed){
    super(name,age);
    this.speed=speed;
  }
}
const tommy=new dog("lion",33,45);
console.log(tommy);

