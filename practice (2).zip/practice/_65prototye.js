// function also use like a object 
// prototype only use in function
// proto and prototype is diff
// prototype is a obj
// function hello(){
// console.log("hii there");
// }
// hello();  
// hello.prototype.abc="hiiii "
// console.log(hello.prototype);
// hello.prototype.sign=function(){
//     console.log("lalall");
    
// }
// hello.prototype.sign();

function createuser(firstName,lastNAme,email,age){
     let user=Object.create(createuser.prototype);
     user.firstName=firstName;
     user.lastNAme=lastNAme;
     user.email=email;
     user.age=age;
     return user;
}
createuser.prototype.about=function(){
    return `${this.firstName} and ${this.lastNAme}`
},
createuser.prototype.is18=function(){
    return this.age>=18;
}

let value1=createuser("pratik","shelage","pratik@gmail.com",20);
let value3=createuser("Sham","shelage","pratik@gmail.com",18);
let value2=createuser("om","sss","om@gmail",9)


console.log(value2.is18());

