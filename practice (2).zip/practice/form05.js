const form=document.querySelector(".signupform")
// console.log(form);
const username=document.querySelector("#username");

const submit=document.querySelector(".btn");
const printuser=document.querySelector(".get-data")
const password=document.querySelector("#password");
const email=document.querySelector("#email");
const about=document.querySelector("#about");


const printpassword=document.querySelector(".get-password");
const printemail=document.querySelector(".get-email");
const printabout=document.querySelector(".get-about");



// console.log(submit);

// submit.addEventListener("click",(e)=>{
 
// e.preventDefault();

// //     data=username.innerHTML;
//   print.innerHTML=username.value

// })

function f1(){

    printuser.innerHTML=username.value;
    printpassword.innerHTML=password.value;
    printemail.innerHTML=email.value;
    printabout.innerHTML=about.value;

}
submit.addEventListener("click",(e)=>{
    e.preventDefault();

    f1();
  
    
})