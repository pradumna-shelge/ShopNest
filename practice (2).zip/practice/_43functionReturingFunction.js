function myfunc(){
    function hello(){
        return "hello world"
    }
    return hello;
}
let ans=myfunc()
console.log( ans());
