// let arr=[1,2,3]
// let array=[...arr];
// console.log(arr);
// console.log(array);

// const obj = { a: 10, b:20 }
// obj.a = 20
// obj.b = 10
// console.log(obj)
// // const obj = { name: "1" }
// console.log(obj)

// let str="pratik";
// let spl=str.split("").join("");
// console.log(spl);

// if number is divisible by 3 print "foo"
// if number is divisible by 5 print "bar"
// if divisible by 3 & 5 print "foo bar"
//  let num=37;
// let divison=function(num){
//        if(num%3==0){
//         console.log("foo");
//        }
//        else if(num%5==0){
//         console.log("bar");
//        }
//        else if(num%3==0 && num%5==0){
//         console.log("foo bar");

//        }

// }
// divison(num);

// const input = "George Raymond Richard Martin";
// let spl=input.split(" ").map((i)=>i.charAt(0))
// console.log(spl.join(""));

// let a = {
//     b: {
//         c: {
//            d: {
//              e : "lorem"
//             }
//         }
//       }
// }

// let {e}=a.b.c.d;
// console.log(e);


// let arr=["pratik","pro","sham"];

// let [item1,item2,item3]=arr;
// console.log(item1);

// let a = {
//     b: {
//         c: "def"
//     },
   
// }

// let{b:{c:{d:{e}}}}=a;
// console.log(e);
// console.log(e);

// // destructring

// let a = ["Test", "Lorem", "Hello"]

// for(let item of a){
//     if(item==="hello"){

//     }

// }
// console.log(a);

// const input = [1, -4, 12, 0, -3, 29, -150];
// let total = 0;

// let sum = input.reduce((acc, curr) => {

//   if (curr > 0) {
//     total += curr;
//   }
//   return total;
// },0);
// console.log(sum);

// let str="2+2";
// let str2=new String("2+2");
// console.log(eval(str));
// console.log(eval(str2.valueOf()));


// const str = "𠮷𠮾";
// console.log(String.fromCodePoint(str.codePointAt(0))); // "𠮷"
// console.log([...str][1]); // "𠮷"
// let str2=[...str];
// console.log(str2);

// const obj = { a: 1, b: { c: 2 } };
// const {

//   c
// } = obj.b

// console.log(c);




// const user = {
//   id: 42,
//   displayName: "jdoe",
//   fullName: {
//     firstName: "Jane",
//     lastName: "Doe",
//   },
// };

// const {firstName,lastName}=obj.fullName
// console.log(firstName);
// console.log(lastName);



let array=["pratik","sham","ram"];

for(let item of array ){
    if(item==indexOf(1)){
      item="ram"
    }  
}
console.log(array);





// const array = [15, 16, 17, 18, 19];

// function reducer(accumulator, currentValue, index) {
//   const returns = accumulator + currentValue;
//   console.log(
//     `accumulator: ${accumulator}, currentValue: ${currentValue}, index: ${index}, returns: ${returns}`,
//   );
//   return returns;
// }

// array.reduce(reducer);


// let obj={
//   name:"pratik",
//   age:20
// }\
// let arr=[1,2,34]

// function add([item1,item2,...item3]){
//   console.log(item3);
//   console.log(item1);
  
  
// }
// add(arr);


// let str="hii pratik";
// let reve=str.split(" ").reverse().join(".")
// console.log(reve);

