const array=["hello","cat","dog","lion"];

//  const ans=array.find((string)=>{
//         return string.length===3 ;
//  })
//  console.log(ans);
 
const users=[
       {userId:1,userName:"harshit"},
       {userId:2,userName:"pratik"},
       {userId:3,userName:"Sham"}
];
// const ans=users.find((a)=>{
//        if(a.userName==="harshit"){
//        a.userName="rohit"
//        }
//        return a.userName

// })
// console.log(ans);

// const ans=users.find((a)=>{
//        if (a.userId==1){
//              return a.userName="ram"
//        }
// })
// console.log(users);
