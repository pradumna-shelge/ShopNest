const input=document.querySelector("#text");
const button=document.querySelectorAll(".buttons button");
const submit=document.querySelector(".submit");
const clear=document.querySelector(".clear");
console.log(submit);


// for(let i of button){
//     i.addEventListener("click",(e)=>{
// e.preventDefault();
// let a=input.value=i.innerHTML;
// let b=input.value=i.innerHTML;
// let c=input.value=i.innerHTML;
// if(b==="+"){
//  input.value=a+c;
// }
//     })
// }

function sub(){
    try{
        input.value=eval(input.value);

    }
    catch(error){
        input.value="Error"
    }
}
function cle(){
    input.value="";
}
submit.addEventListener("click",(e)=>{
    e.preventDefault();
    sub();
   
})
clear.addEventListener("click",(e)=>{
    e.preventDefault();
    cle();
})

