function sing(){
console.log("happy happy happy");

}
function sum(number1,number2){
return number1+number2;    
}
console.log(sum(4,5));


function iseven(num){
    return num%2===0 ? "even" :"odd"
}

console.log(iseven(5));


function char(name){
return name[0];
}
console.log(char("pratik"));

function array(num){
     for (let i = 0; i < num.length; i++) {
     if(num[i]%2===0){
        console.log(num[i]);
        
     }

        
     }
    
}
const my=[1,2,3,4,5]
console.log(array(my));

