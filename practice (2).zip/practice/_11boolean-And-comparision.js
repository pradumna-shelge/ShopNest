let num1="7";
let num2=7;
console.log(num1<num2);

console.log(num1===num2);

console.log(num1!==num2);
