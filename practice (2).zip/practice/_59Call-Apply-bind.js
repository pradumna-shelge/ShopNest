// call

// const user1={
//     firstName:"pratik",
//     age:33,
//     about:function(){
//         console.log(`name is ${this.firstName} and age is  ${this .age}`);      
//     }
// }
// const user2={
//     firstName:"Pradip",
//     age:33,
// }

// user1.about.call(user2); 
// when you use call always pass the this value in it;call use for to borrow the function value to another object
// also
function about(hobby,pass){
    console.log(`name is ${this.firstName} and age is  ${this .age}  `,hobby,pass);      
}
const user1={
    firstName:"pratik",
    age:33,
   
}
const user2={
    firstName:"Pradip",
    age:33,
}
// about.call(user1,"swimming","ticket");
// apply
about.apply(user2,["guiter","show"]);

// bind

// const func=about.bind(user2,"guiter","show");
// func();
// bind give as a function to call whenever you want
// dont create varible to store the about function beacues they dont get this CSSMathValue,but if you want it so use bind with it
// const myfunc=user1.about; <-dont do this  const myfunc=user1.about.bind(user1); do this
// myfunc()
