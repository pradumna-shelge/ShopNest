let firstName="";

if(firstName){
    console.log(firstName);
    
}
else{
    console.log("first kinda empty");
    
}