// let person={
//     fullName:function(){
//         return this.fname +" " +this.lname
//     }
// }

// let man={
//     fname:"rohit",
//     lname:"shinde"
// }
// let women={
//     fname:"anu",
//     lname:"sharma"
// }

// person.fullName.call(man)

// let person={
//     fullName:function(age,place){
//         return this.fname +" " +this.lname +"  " +age+" "+place
//     }
// }

// let man={
//     fname:"rohit",
//     lname:"shinde"
// }
// let women={
//     fname:"anu",
//     lname:"sharma"
// }

// let ok=person.fullName.call(man  ,22,"latur")
// console.log(ok);

// console.log(Math.max(1,2,3));

// let person={
//     name:"pratik",
//     age:20,
//     display:function(){
//         return this.name +" " +this.age;
//     }
// }
// let member={
//     name:"rohan",
//     age:20
// }

// let ok=person.display.bind(member);

// console.log(ok());

// let add=(function relax(){
//     let a=5;
//     return function add(a){ return a*a}

// })();

// console.log(add());

// function value(qua){
//     const be="hi".repeat(qua);
//     return be;

// }

// let val=value(4);
// console.log(val);

// anonimus function
// console.log(make(8));error  Cannot access 'make' before initialization

// const make=function(i){
//     return i*i
// }
// console.log(make(8));

// immediately invoked function expression

// (function (){

// }())

// practice

// const obj = { a: 10, b:20 }
// obj.a = 20
// obj.b = 10
// console.log(obj.a)

// const input = "George Raymond Richard Martin";
// let val=input.split(" ")

// for(let i of val){

// if(i==i){
//     console.log(i.charAt(0));

// }

// }

//
// let a = {
//     b: {
//         c: {
//            d: {
//              e : "lorem"
//             }
//         },
//         f: "g",
//     }
// }

// let {f}=a.b;
// console.log(f);

// const input = [1, -4, 12, 0, -3, 29, -150];

// let value=input.filter((i)=>i>0).reduce((acc,curr)=>acc+curr);
// console.log(value);

const input = [
  { name: "John", age: 13 },
  { name: "Mark", age: 56 },
  { name: "Rachel", age: 45 },
  { name: "Nate", age: 67 },
  { name: "Jennifer", age: 65 },
];
// let change=input.find((i)=>{
//     if(i.age===56){
//        i.name="mohit"
//     }
//     return i.name;

// })
// console.log(change);

// for (let i of input){
//     if (i.age===56){
//         i.name="rohit"
//     }
// console.log(i);

// }

// Check 2 strings are same or not. Strings will be incase sensitive.
 
// this iS LoREmIPsum
// This IS lOreMipSUM
 
// output : true

// let str1="this iS LoREmIPsum";
// let str2="This IS lOreMpSUM"

// let str=str1.toLowerCase();
// let st=str2.toLowerCase();

// if (str===st){
//     console.log(true);
    
// }
// else{
//     console.log(false);
    
// }

// Given a string, reverse each word in the sentence
// "Welcome to this Javascript Guide!"
// // Output becomes !ediuG tpircsavaJ siht ot emocleW

// let str="Welcome to this Javascript Guide!";

// let st=str.split("").reverse().join("")
// console.log(st);

// Remove spaces with single space throughout
 
// let str = "   Welcome    to   string    concepts   of JavaScript   ";
// Output = Welcome to string concepts of JavaScript
// Hint: /\s+/g to remove spaces use this regex

// let str = "   Welcome    to   string    concepts   of JavaScript   ";
// let st=str.trim().replace(/\s+/g ," ");
// console.log(st);

// let arr = ["Apple", "Orange", "Lichi", "Kiwi"];

// for(let i of arr){
//     let st=i.charAt(i.length-1);
//     console.log(st);
    
    
// }

// Write a function to Get the Last N Characters of a String.
 
// lastStrings("Loremipsumdolor", 5)
// // output : dolor


// function lastStrings(i,b){
 
// let det=i.slice(-b);
// console.log(det);


// }
// lastStrings("Loremipsumdolor", 5)


// Find the Median of Two Sorted Arrays

// Problem: Given two sorted arrays, find the median of the two arrays.

// [1, 3], [2] -> 2.0


// function arr(a,b){
//  let sp=[...a,...b];
// let sum=0;
// for(let i of sp){
//     sum+=i;
// }
// return sum/sp.length

// }

// console.log(arr([1, 3],[2]));


// function array(arr1,arr2){
//   let com=arr1.filter((item)=>arr2.includes(item));
//   return com;
// }
// console.log(array([1,2,3,4],[3,4,5,6]));


// Convert an object to an array of key-value pairs:
// console.log(objToArr({ a: 1, b: 2 })); // [['a', 1], ['b', 2]]
// function objToArr(a){
//     return Object.entries(a)
// }


// console.log(objToArr({ a: 1, b: 2 }));



// Find the Maximum Number

// Write a function findMax(arr) that takes an array of numbers arr and returns the maximum number.

// Example:

// function findMax(a){
//     console.log(Math.max(...a));
    
// }
// findMax([3, 5, 7, 2, 8]); 

