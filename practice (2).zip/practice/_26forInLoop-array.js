let fruits=["apple","mango","banana","grapes"];

for(let idx in fruits){
    console.log(idx);
    
}