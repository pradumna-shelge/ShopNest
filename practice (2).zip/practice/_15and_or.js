let firstName="harshit";
let age=22;
// if(firstName[1]==="a"){
//     console.log("your name start with h");
    
// }

// if(age>18){
//     console.log("your not a teenager");   
// }


if(age>18 && firstName[3]==="p"){
    console.log("you are enough");
    
}else {
    console.log("inside else");
    
}
