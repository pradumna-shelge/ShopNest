console.log("hii");

let s=setTimeout(() => {
    console.log("print the data");
    
}, 0);

for (let i = 0; i <10; i++) {
    console.log(i);
    
    
}

console.log("hii there");
clearTimeout(s);
console.log("print");


