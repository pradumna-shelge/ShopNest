const user1={
    firstName:"pratik",
    age:33,
    about:function(){
        console.log(`name is ${this.firstName} and age is  ${this .age}`);      
    }
}
user1.about();

// in the arrow function this keyword is on the next level means it is not taking the object it taking the window;