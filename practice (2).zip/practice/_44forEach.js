const arr=[1,2,3,4];
// arr.forEach(function(num,index){
//     console.log(`${index} and ${num*2}`);
    
// })
// arr.forEach((number)=>{
//      console.log(number);
// });

// let array=function squre(num){
//        return num*2;
// }
// const sure=arr.map(array)
// console.log(sure);
arr.forEach((num)=>{
console.log(num*num);

})


