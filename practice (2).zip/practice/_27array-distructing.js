// let fruits=["apple","mango","banana","grapes"];
// let [myarr1,myarr2, ,...all]=fruits;
// console.log(myarr1);
// console.log(myarr2);
// console.log(all);


let arr=[1,2,3,4,5];

let [num1,num2,,...num3]=arr;
console.log(num3);
