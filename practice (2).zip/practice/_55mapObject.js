const person=new Map();
console.log(person);
person.set("name","pratik");
person.set("1","one");
console.log(person.get("name"));

// // console.log(person.keys());

for (let key of person.keys()){
    console.log(key);
    
}
for(let key of person){
    console.log(key);
    
}
// const person1={
//     id:1,
//     name:"pratik"
// } 

// const user=new Map();
// user.set(person1,{age:8,gender:"male"})
// // console.log(user);
// console.log(person1.id);

// console.log(user.get(person1).gender);



// const person =new Map([['pratik','sham'],['age',7]] );
// // console.log(person);
