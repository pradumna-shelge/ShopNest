const arr=[1,3,5];
const all=arr.some((num)=>num%2===0)
console.log(all );
