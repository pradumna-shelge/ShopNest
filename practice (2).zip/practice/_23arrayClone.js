let arr=["mango","apple","banana"];
// let array=arr.slice(0);
// let array=[].concat(arr)
let array=[...arr,"hii there" ]
arr.push("item4");
console.log(arr);
console.log(array);

