let fristName="harshit";

// console.log(fristName.length);
// fristName=fristName.trim();
// console.log(fristName);
// console.log(fristName.length);

// fristName=fristName.toLowerCase
//  console.log(fristName);
 
let newString=fristName.slice(0,4);
console.log(newString);




