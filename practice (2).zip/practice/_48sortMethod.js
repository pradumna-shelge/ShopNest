   const number=[3,4,5,7,99,100,34,111];
   // number.sort((a,b)=>a-b)
   // console.log(number);
   
  let num=number.sort()
  console.log(num);
  