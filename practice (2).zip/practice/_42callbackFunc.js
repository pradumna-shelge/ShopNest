function myfunc(callback){
console.log("hii there");
callback();
}
function myfunc2(){
    console.log("hey buddy");
    
}
myfunc(myfunc2); 