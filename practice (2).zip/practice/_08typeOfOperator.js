let h=20;
let fristName="pratik"
console.log(typeof fristName);


console.log(typeof (h + ""));


let myStr=+"34"
console.log(typeof myStr);

let age ="18"
age=Number(age);
console.log(typeof age);

