const numbers=[2,3,4,5,1];

//  const squre=numbers.map((num)=>{
//          return num*2;
//  })

//  console.log(squre);
 const add=numbers.map((a)=>a+1);
 console.log(add);
 