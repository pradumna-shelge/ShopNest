let age=8;
let drink=age>=5 ? "cofee":"milk";
console.log(age>6?"gret":"less");

console.log(age<10 ? "less":"high");
