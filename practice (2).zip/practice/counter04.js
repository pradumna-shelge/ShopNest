const value=document.querySelector(".value");
// console.log(value);
const decrease=document.querySelector(".down");
const increase=document.querySelector(".up");
// console.log(increase);
let count=0;

value.innerHTML=count

increase.addEventListener("click",()=>{
 count++;
   value.innerHTML=count;
})

decrease.addEventListener("click",()=>{
    count--;
    value.innerHTML=count;
})