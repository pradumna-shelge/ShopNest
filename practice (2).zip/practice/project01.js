// const rootNode=document.getRootNode();
// const htmlElement=rootNode.childNodes[0];
// // console.log(htmlElement.childNodes);NodeList(3) [head, text, body]
// let htmlElementhead=htmlElement.childNodes[0];
// let textElement=htmlElement.childNodes[1];
// let bodyElement=htmlElement.childNodes[2];
// console.log(htmlElementhead.nextElementSibling);

// let h1=document.querySelector(".container h1");
// let body=h1.parentNode.parentElement;
// body.style.backgroundColor="red";
// body.style.color="white"

// const body=document.body
// console.log(body);
// const  head=document.querySelector("head");
// const title=head.querySelector("title")
// console.log(title.childNodes);

const container=document.querySelector(".container");
console.log(container.children);
