let fristName="harshit"
fristName="pratik"
console.log(fristName);