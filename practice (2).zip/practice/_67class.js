 class createuser {
         constructor(firstName,lastNAme,email,age){
            this.firstName=firstName;
            this.lastNAme=lastNAme;
            this.email=email;
            this.age=age;
         }
         about(){
             return `${this.firstName} and ${this.lastNAme}`
         }
         is18(){
            return this.age>=18;
         }
 }
 
let value1= new createuser("pratik","shelage","pratik@gmail.com",20);
let value3= new createuser("Sham","shelage","pratik@gmail.com",18);
let value2= new createuser("om","sss","om@gmail",9)


console.log(value1.about());
console.log(value2.age);







 
