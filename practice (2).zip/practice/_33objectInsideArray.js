 const user=[
    {userid:1,
        name:"harshit",
        gender:"male"
    },
    {userid:2,
        name:"pratik",
        gender:"male"
    },
    {userid:3,
        name:"jolly",
        gender:"female"
    }
]
// console.log(user);

for (let item of user){

    if(item.userid===1){
        console.log(item.name);
        
    }
}

// nested destructuring
const [user1,user2,user3]=user;
console.log(user1);
const [{name:namo}, ,{gender}]=user;
console.log(namo);

