// Check 2 strings are same or not. Strings will be  sensitive.

// this iS LoREmIPsum

// This IS lOreMipSUM

// output : true

// let str1="this iS LoREmIPsum";
// let str2="This IS lOreMipSUM";

// let firstlow=str1.toLowerCase();
// let secondlow=str2.toLowerCase();

// if(firstlow===secondlow){
//     console.log(true);

// }
// else{
//     console.log(false);

// }

// function compare(a,b){
// return a===b ? "true":"false"
// }
// compare(str1,str2)
// function areStringsSame(str1, str2) {
//      return str1 === str2;
//  }

//  let string1 = "this iS LoREmIPsum";
//  let string2 = "This IS lOreMipSUM";

//  areStringsSame(string1, string2); // This will return false

// Given a string, reverse each word in the sentence
// "Welcome to this Javascript Guide!"
// // Output becomes !ediuG tpircsavaJ siht ot emocleW

// let str="Welcome to this Javascript Guide!";
// let reve=str.split("").reverse().join("");
// console.log(reve);

// Remove spaces with single space throughout

// let str = "   Welcome    to   string    concepts   of JavaScript   ";

// Output = Welcome to string concepts of JavaScript

// Hint: /\s+/g to remove spaces use this regex

// let str = "   Welcome    to   string    concepts   of JavaScript   ";
// let removeSpace=str.trim().replace(/\s+/g," ")
// console.log(removeSpace);

// function removeSpace(a){
//     let str1=a.trim();
//     console.log(str1);

// }
// removeSpace(str);

// get the last character of a string in every word

// let arr = ["Apple", "Orange", "Lichi", "Kiwi"]
// output = ["e", "e", "i", "i"];

// let arr = ["Apple", "Orange", "Lichi", "Kiwi"]
// let a=[];
// for(let item of arr){
//      let last=item.charAt(item.length-1)
//      a.push(last)

// }
// console.log(a);

// let a= "Apple";
// let last=a.charAt(a.length-1)
// console.log(last);
// let aa=[];
// for(let item of arr){
// let last=item.charAt(item.length-1)

// }

// output: "e"

// Write a function to Get the Last N Characters of a String.

// lastStrings("Loremipsumdolor", 5)

// // output : dolor
//  snnipet
// let str="Loremipsumdolor";
// function last(a,b){
//      let str2=a.slice(b);
//      console.log(str2);

// }
// last(str,-5)

// let str="pratik";
// console.log(typeof str);

// let str="";
// function blank(str){
//    return str.length!==0?"false":"true"
// }

// console.log(blank(str));

// let str="robin seb"
// let str2=str.slice(str,4);
// console.log(str2);

// 7. Write a JavaScript function to parameterize a string.
// Test Data :
// console.log(string_parameterize("Robin Singh from USA."));
// "robin-singh-from-usa"

// let str="Robin Singh from USA.";
// let str2=str.split(" ").join("-")
// console.log(str2);

// 8.Write a JavaScript function to capitalize the first letter of a string.
// Test Data :
// console.log(capitalize('js string exercises'));
// "Js string exercises"

// function cap(str){
//     let str2= str[0].toUpperCase();
//     let str3=str.slice(1)
//     return str2+str3
// }
// console.log(cap('js string exercises'));

// 19. Write a JavaScript function that takes a string with both lowercase and upper case letters as a parameter. It converts upper case letters to lower case, and lower case letters to upper case.
// Test Data :
// console.log(swapcase('AaBbc'));
// "aAbBC"

// error

// function upLow(str){
//     let str2=str.split("");
//     for(let i of str2){
//      // console.log(i);

//        if(i==i.toLowerCase()){
//             return i.toUpperCase();
//        }
//        else if(i==i.toUpperCase()){
//           return i.toLowerCase();
//        }

//      }

//      return str2;
// }

// console.log(upLow("AbCd"));

// 13. Write a JavaScript function to concatenate a given string n times (default is 1).
// Test Data :
// console.log(repeat('Ha!'));
// console.log(repeat('Ha!',2));
// console.log(repeat('Ha!',3));
// "Ha!"
// "Ha!Ha!"
// "Ha!Ha!Ha!"

// function repeat(str){
//  let str2=str.repeat(3);
//  return str2;

// }
// console.log(repeat("ha"));

// 16. Write a JavaScript function to truncate a string if it is longer than the specified number of characters. Truncated strings will end with a translatable ellipsis sequence ("...") (by default) or specified characters.
// Test Data :
// console.log(text_truncate('We are doing JS string exercises.'))
// console.log(text_truncate('We are doing JS string exercises.',19))
// console.log(text_truncate('We are doing JS string exercises.',15,'!!'))
// "We are doing JS string exercises."
// "We are doing JS ..."
// "We are doing !!

// function half(str,b){
//       if(str.length>b){
//           return str.slice(0,b)+"...";
//       }
// }
// console.log(half("928454233001",10));

// arrray

// 2. Write a JavaScript function to clone an array.
// Test Data :
// console.log(array_Clone([1, 2, 4, 0]));
// console.log(array_Clone([1, 2, [4, 0]]));
// [1, 2, 4, 0]
// [1, 2, [4, 0]]

// function clone(arr){
//     //   let clone2=[...arr];
//     //   return clone2;
//     return arr.slice(0)
// }
// console.log(clone([1,2,[3,0]]));

// Write a JavaScript function to check whether an 'input' is an array or not.

// Test Data:
// console.log(is_array('w3resource'));
// console.log(is_array([1, 2, 4, 0]));
// false
// true

// function check(input){
//    return Array.isArray(input)
// }
// console.log(check('hii'));

// Write a simple JavaScript program to join all elements of the following array into a string.
// Sample array : myColor = ["Red", "Green", "White", "Black"];
// Expected Output :
// "Red,Green,White,Black"
// "Red,Green,White,Black"
// "Red+Green+White+Black"

// function str(arr){
// return arr.toString();
// }
// console.log(str(["ram","sham"]));

// Write a JavaScript program to sort the items of an array.
// Sample array : var arr1 = [ -3, 8, 7, 6, 5, -4, 3, 2, 1 ];
// Sample Output : -4,-3,1,2,3,5,6,7,8

// function sort(i){
//  let syn=i.sort((a,b)=>a-b)
//  return syn.toString();
// }
// console.log(sort([ -3, 8, 7, 6, 5, -4, 3, 2, 1 ]));

// Write a JavaScript program to find the most frequent item in an array.
// Sample array : var arr1=[3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3];
// Sample Output : a ( 5 times )

// error
// function repeat(item){
//     let count=0;
//     for(let i=0;i<item.length;i++){
//         for(let j=i;j<item.length;j++){
//              if(item[i]==item[j]){
//                 count++
//              }
//         }
//     }
//     return count;
// }
// console.log(repeat([3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3]));

// object

// 1. Write a JavaScript program to delete the rollno property from the following object. Also print the object before or after deleting the property.
// Sample object:
// var student = {
// name : "David Rayy",
// sclass : "VI",
// rollno : 12 };

// var student = {
// name : "David Rayy",
// sclass : "VI",
// rollno : 12 };

// delete(student.name);
// console.log(student);

// 3. Write a JavaScript program to get the length of a JavaScript object.
// Sample object :
// var student = {
// name : "David Rayy",
// sclass : "VI",
// rollno : 12 };

// var student = {
// name : "David Rayy",
// sclass : "VI",
// rollno : 12 };
// let count=0;
// for (let key in student){
//     if(key==key){
//         count++;
//     }

// }
// console.log(count);

// 4. Write a JavaScript program to display the reading status (i.e. display book name, author name and reading status) of the following books.

// var library = [
//    {
//        author: 'Bill Gates',
//        title: 'The Road Ahead',
//        readingStatus: true
//    },
//    {
//        author: 'Steve Jobs',
//        title: 'Walter Isaacson',
//        readingStatus: true
//    },
//    {
//        author: 'Suzanne Collins',
//        title:  'Mockingjay: The Final Book of The Hunger Games',
//        readingStatus: false
//    }];

//    for(let i of library){
//     console.log(i.readingStatus);

//    }

// let arr=[1,2,3,4,5];
// let str=arr.map((i)=>i+"apple");
// console.log(str);

// let arr=["pratik","ram","sham"];

// for(let i of arr){
// if(i==i.length){
//     console.log(i);

// }
// }

// function plusMinus(arr) {
//   let plus = 0;
//   let minus = 0;
//   let nutral = 0;

//   for (let i = 0; i < arr.length; i++) {
//     if (arr[i] == 0) {
//       nutral++;
//     } else if (arr[i] > 0) {
//       plus++;
//     } else if (arr[i] < 0) {
//       minus++;
//     }
//   }
//   let a= nutral / arr.length;
  
//   let b= minus / arr.length;

//   let c= plus/ arr.length;

//   console.log(a.toFixed(5));
//   console.log(b.toFixed(5));
//   console.log(c.toFixed(5));

  
// }
// plusMinus([1,2,0,-1,-2])

// // console.log(plusMinus([1, 2, 0, -1, -2]));






// Sort an array of strings alphabetically
// ['banana', 'apple', 'cherry'] 

// let arr=['banana', 'apple', 'cherry'] ;

// let sorted=arr.sort();
// console.log(sorted);

// // Find the difference between two arrays:
// // console.log(difference([1,2,3], [2, 3, 4])); //1;
// error---------------------
// function difference(a,b){


// }



// console.log(difference([1,2,3], [2, 3, 4]));


// Find the Median of Two Sorted Arrays
// Problem: Given two sorted arrays, find the median of the two arrays.
// [1, 3], [2] -> 2.0   
//  function medium(a,b){
    // let add=0;
    // let add2=0;
    // let sum=a.length+b.length;
    // // console.log(sum);
    // for(let i of a){
    //    add+=i;
    // }
    // // console.log(add);
    // for (let i of b){
    //     add2+=i;
    // }
    // let sum2=add+add2;
    // // console.log(sum2);
    
    // return sum2/sum;
//     let add=[...a,...b];
//     let total=0;
//      let mid=add.reduce((acc,curr)=>{
//             total+=curr;
//             // return total/add.length;
            
//      },0)
//      console.log(total/add.length);


//     // return add;
    
//  }
//  medium( [1, 3], [2])
// console.log(medium( [1, 3], [2]));

// Convert an object to an array of key-value pairs:
// console.log(objToArr({ a: 1, b: 2 })); // [['a', 1], ['b', 2]];

function objToArr(a){
    // let arr=[];
    // for(let i in a){
    //     arr.push(i,a[i]);
    // }
    // return arr;
    // for (let [key,value] of Object)
     console.log(Object.entries(a))

}

objToArr({ a: 1, b: 2 });