// const arr = [
//   { id: 1, name: "pratik", email: "Pratik@gmail.com" },
//   { id: 2, name: "om", email: "om@gmail.com" },
//   { id: 3, name: "Ram", email: "Ram@gmail.com" },
// ];

// let you=arr.map((item) => {
//   if (item.id === 1) {
//     return item.name;
//   }
// });
// console.log(you);

// function countDown(number) {
//   console.log(number);
//   if (number > 0) {
//     countDown(number - 1); // The function calls itself
//   }
// }

// countDown(5); // Counts down from 5 to 0

// question in array

// const arr = ["pratik", "ram", "sham", "krishna", "pradumna"];

// // for (let i=0;i<arr.length;i++){
// //   console.log(arr[i]);

// // }

// // arr.forEach((item)=>{
// // console.log(item);
// // })

// for (const item of arr) {
//   console.log(item);

// }

//
// const sumOfArray=[3,4,6,4,6,8,93];
// let sum=0
// for(let i=0;i<sumOfArray.length;i++){
//     sum=sum+sumOfArray[i];

// }
// console.log(sum);

// sumOfArray.forEach((item)=>{
//   sum+=item
// })
// console.log(sum);

// for(const item of sumOfArray){

//   sum+=item;

// }
// console.log(sum);

// for (let i = 1; i <= 10; i++) {
//   let row = '';
//   for (let j = 1; j <= 10; j++) {
//     row += (i * j) + '\t';
//   }
//   console.log(row);
// }
// Original toy box with toys

// // map

// // const number=[3,4,5,6,7]

// // const square=function(number){
// //     return number*number
// // }

// // const snumber=number.map((number)=>{
// //     return number*number
// // })
// // console.log(snumber);

// // const snumber=number.map(function(item,idx){
// //     return `index:${idx},${item*item}`
// // })
// // console.log(snumber);\

// // let arr=function(number){
// //     return number*number
// // }

// // let secondaArr=number.map(arr);
// //      console.log(secondaArr);

// const Arr=[
//     {firstName:"pratik",age:20},
//     {firstName:"Ram",age:20},
//     {firstName:"Sham",age:20},
// ]

// let storeValue=Arr.map((item)=>{
//       return item.firstName
// })
// console.log(storeValue);

// let store=function(Arr){
//     return Arr.age
// }

// let newArray=Arr.map(store)

// console.log(newArray);

// let store=Arr.map(function(item){
//     return item.age
// })

// console.log(store);

// filter method

const number = [1, 2, 3, 45, 5];

// let isEven=function(number){
//     return number%2!==0;
// }

// const even=number.filter(isEven);
// console.log(even);

// const even=number.filter(function(item){
//     return item%2===0;
// })
// console.log(even);

// const even=number.filter((item)=>{
//   return item%2==0
// })
// console.log(even);

// reduce method

// const arr=[1,2,3,4]

// const sum=arr.reduce((accumulator,currentvalue)=>{
//     return accumulator+currentvalue
// })
// console.log(sum);

// // // accumulator, currentVlaue ,return
// //       1              2           3
// //       3              3           6
// //       6              4           10

// const userCart=[
//     {productid:1,productName:"mobile",price:12000},
//     {productid:2,productName:"latop",price:29929},
//     {productid:3,productName:"Tv",price:22626},
// ]

// const total=userCart.reduce((totalPrice,currentProduct)=>{
//     return totalPrice+currentProduct.price

// },0)

// console.log(total)

// practice

// const users=[
//     {firstName:"john",lastName:"Biden",age:26},
//     {firstName:"jimmy",lastName:"cob",age:75},
//     {firstName:"sam",lastName:"lewis",age:50},
//     {firstName:"Ronald",lastName:"Mathew",age:26},
//   ];

//   const fullName=function(users){
//     return `${users.firstName} ${users.lastName}`
//   }

//   const value=users.map(fullName)
//   console.log(value);

// const users=[
//     {firstName:"john",lastName:"Biden",age:26},
//     {firstName:"jimmy",lastName:"cob",age:75},
//     {firstName:"sam",lastName:"lewis",age:50},
//     {firstName:"Ronald",lastName:"Mathew",age:26},
//   ];
//   //using reduce array method
//   const output=users.reduce(function(acc,curr){
//       if(acc[curr.age])
//       //if present in array object
//       {
//           acc[curr.age]++;
//       }else{
//       //if not present in array object
//         acc[curr.age]=1;
//       }
//       return acc;
//   },{})
//   console.log(output);

// let student =[
//     {name:"Smith",rollNumber:31,marks:80},
//     {name:"Jenny",rollNumber:15,marks:69},
//     {name:"John",rollNumber:16,marks:35},
//     {name:"Tiger",rollNumber:7,marks:55}
//    ];

// let total =student.reduce((totalvalue,cuureent)=>{
//     return totalvalue+cuureent.marks
// },0
// )
// console.log(total);

// const users=[
//     {firstName:"john",lastName:"Biden",age:26},
//     {firstName:"jimmy",lastName:"Cob",age:75},
//     {firstName:"Sam",lastName:"Lewis",age:50},
//     {firstName:"Ronald",lastName:"Mathew",age:26},
//   ];

//   const combo=users.filter((item)=>item.age>50).map((item)=>item.firstName)

// console.log(combo);

// let student = [
//   { name: "Smith", rollNumber: 31, marks: 80 },
//   { name: "Jenny", rollNumber: 15, marks: 69 },
//   { name: "John", rollNumber: 16, marks: 35 },
//   { name: "Tiger", rollNumber: 7, marks: 55 },
// ];

// let total = student
//   .map((item) => {
//     if (item.marks < 60) {
//       item.marks += 20;
//     }
//     return item;
//   })
//   .filter((item) => {
//     return item.marks > 60;
//   })
//   .reduce((acc, curr) => {
//    return acc + curr.marks;
//   }, 0);
// console.log(total);

// const arr=["pratik","ram","sham"]

// const Upper=arr.map((item)=>{
//     return item.toUpperCase();
// })

// console.log(Upper);

// // const userCard =
// let a=document.querySelector("#entervalue")

// a.addEventListener("input",function(item){
//     console.log(item.target.value);
// })

// let obj={name:"pratik"}
// obj.year=2014;
// console.log(obj.name);

// function add(a,b){
//     return a+b;
// }
// console.log(add(3,4));

// let str="pratik ,shelage"
// let str1="vaijanth"
// let string="  pratik  "
// console.log(str.toUpperCase());
// console.log(str.indexOf("shelage"));
// console.log(str.replace("shelage",""));
// console.log(str.concat(" ",str1));
// console.log(str.split(","));
// console.log(string.trim());
// console.log(str1.split(""));

// // array

// let arr=["pratik","sham","ram","mohan"];
// console.log(arr.indexOf("sham"));
// console.log(arr.includes("pratik"));
// console.log([...arr,...arr]);

// let num=[1,24,5,6,75,3];
// let ok=num.sort();
// console.log(ok);

// num.sort(function(a,b){return a-b})
// console.log(num);

// let numArray = [3, 4, 1, 7, 2];
// let sortedArr = numArray.sort();
// console.log(sortedArr);

// // object

// let obj = { name: "pratik", age: 22 };
// let obj2 = {
//   name: "kedar",
//   male: "yes",
// };
// // let onb={...obj,...obj2}
// obj.gender="male";
// // obj.name="sham"
// // delete(obj.age);
// let own = obj.hasOwnProperty("name");
// console.log(own);
// for (let key in obj) {
// console.log(`${key} :${obj[key]}`);
// console.log(obj[key]);
// console.log(delete(obj[key]));
// console.log(obj);

// }
// console.log(obj);

// let newobj={...obj,value:2999}
// console.log(newobj);

// console.log(obj);

// function
// const add=(a,b)=>{
// return a+b
// }
// console.log(add(2,4));

// imediate invoke function

// let result =(function(){
//     console.log("home");

// })();

// callbackfunction
// let arr=["pratik","sham","kam"];

// function getName(callback){
//     console.log("get name one by one");
// callback(arr);
// }
// function printvalue(item){
//   for(let name of item){
//     console.log(name);

//   }

// }
// getName(printvalue);

// default parameter

// const name=(name="pratik")=>{
//   return name;
// }
// console.log(name());

// rest parameter
// let sum=0;
// const sumall=(...number)=>{
//    for(let item of number){
//     sum+=item;
//    }
//    return sum;
// }
// sumall(1,2,3,4);
// console.log(sum);

// function check(value){
//    console.log(typeof value);

// }
// check("pratik")

// let arr=[1,2,3,4];

// let sum=0;
// for(let item of arr){
// sum+=item
// }
// console.log(sum);

//
// how many vowles in string

// let str="pratik";

// let vowels=str.split("");
// let count=0
// for(let item of vowels){
//   if(item==="a" || item==="e" || item==="i" || item==="u" || item==="o"){
//     count++;
//   }
// }
// console.log(count);

// let vowles=function(a){
//    let count=0;
//    let vow=a.split("");
//    for(let item of vow){
//       if(item==="a" || item==="e" || item==="i" || item==="u" || item==="o"){
//         count++;
//       }
//     }
//     console.log(count);

// }

// vowles("pratik")

// how to know the string is the palidrom or not

// let palidrom=function(a){
//      let split=a.split("").join();
//      console.log(split);

//      let reverse=a.split("").reverse().join();
//      console.log(reverse);

//      if(split===reverse){
//         console.log("palidrome");
//      }
//      else{
//         console.log("not a palindrom");

//      }
// }

// palidrom("abcdef");

// let str="mam";
// let reverse1=str.split("").join();

// let reverse=str.split("").reverse().join();

// if(reverse1===reverse){
//     console.log("string is palidrome");

// }
// else{
//     console.log("not a palidrom");

// }

// find the diff in string

// let str1 = "";
// let split1 = str1.split("");

// let str2 = "y";
// let split2 = str2.split("");

// for (let i = 0; i < split2.length; i++) {
//   for (let j = 0; j <=split1.length-1; j++) {
//     if(split1[i]===""){
//        console.log(split2[i]);
//     }
//     else if (split2[i] === split1[i]) {
//       break;
//     } else if (split2[i] !== split1[i]) {
//       console.log(split2[i]);
//       break;
//     }

//   }
// }

// for(let i of str1){
//     console.log(i);

//     // for( let j of split2){
//     //     if(i===j){
//     //         console.log(i);

//     //     }
//     // }
// }

// find the missing number from the distinct array

// let arr = [1, 2, 3, 4, 0, 6];
// arr.sort();
// // console.log(arr);
// let count = 0;
// for (let i = 0; i <= arr.length; i++) {
//   if (count === 1) {
//     break;
//   } else if (i === arr[i]) {
//   } else if (i !== arr[i]) {
//     console.log(i);
//     count++;
//   }
// }

// console.log(i);
// for(let v=0;v<arr.length;v++){
//    if(i===arr[v])  {
//      break;
//    }
//    else if(i !== arr[v]){
//     console.log(i);
//     break;

//    }
// }

// let str1 = "";
// let str2 = "a";

// let str=[...str1,...str2];

// let missing=str.pop();
// console.log(missing);
// let s="abdc";
// let t="abc"

// s = s.split('').sort();
// t = t.split('').sort();

// for(let i = 0; i < t.length; i++){
//     if(s[i] !== t[i]) {
//         console.log(t[i]);

//     }
// }

// let arr = [1, 2, 3, 3];
// let value=0;
// let count = 0;

// for (let i = 0; i < arr.length; i++) {
//   if (arr[i]) {

//   }

// }

// function dupli(num){
//   console.log(num.length);

//    let arr=new Set (num);
//   if(arr.size!==num.length){
//     return true;
//   }
//     return false;

// }
// let value=[1,2,3];
// console.log(dupli(value));

// unsorted =["1","200","150","3"]
//  array ['1', '3', '150', '200']

//  function main(arr){
//   for(let i=0;i<arr.length;i++){
//     for( let j=i;j<arr.length;j++){

//        if(arr[i]>arr[j+1]){
//         let temp=arr[i];
//         arr[i]=arr[j+1];
//         arr[j+1]=temp;
//        }

//       }
//       console.log(arr);
//         }

//  }
//  let unsorted =[1,3,2]
//  main(unsorted);

// const obj=[{name:"pratik",age:22,gender:"male"},{name:"sham",age:20,gender:"male"},{name:"rohini",age:18,gender:"female"}];

// for (let item of obj){
//     if(item.name==="rohini"){
//         delete(item.name);
//     }
// }
// console.log(obj)
// ______________________________
// const obj={name:"pratik",age:22,gender:"male"};
// obj.cute="yes";
// console.log(obj['name']);
// _____________________________
//  const obj={name:"pratik",age:22,gender:"male"};
// for(let key in obj){
//     console.log(`${key}:${obj[key]}`)
// }
// ______________________________
// const obj={name:"pratik",age:22,gender:"male"};
// console.log(obj.cute)
// ____________________________
// imp
// const obj={name:"pratik",age:22,gender:"male"};
// if(obj.hasOwnProperty("name")){
//     console.log("true")
// };
// ______________
// const obj={name:"pratik",age:22,gender:"male"};
// console.log(obj.keys());
// _____________________
// const obj={name:"pratik",age:22,gender:"male"};

// const newObj={...obj,cute:"yes"};
// console.log(newObj);
// console.log(obj);
// ___________________________
// const obj={name:"pratik",age:22,gender:"male" , about:function(){
//     return `${this.name}`
// }};
// console.log(obj.about())

// __________________
// const obj={name:"pratik",age:22,gender:"male" , about:function(){
//     return `${this.name}`
// },hobiess:["cricket","villyboll"]};
// obj.hobiess.pop()
// console.log(obj)
// let arr=[1,2,3,4];
// // console.log(arr)
// let array=[];
// for(let i=arr.length-1;i>=0;i--){
//     // console.log(arr[i])

//     array.push(arr[i]);
// }
// console.log(array)

// let arr=[1,2,3,4];
// console.log(arr)
// let array=[];
// for(let i=arr.length-1;i>=0;i--){
//     // console.log(arr[i])

//     array.push(arr[i]);
// }
// console.log(array)
// ______________________________
// let arr=[1,2,3,4,5];
// let arr2=[3,4,5,6,7];

// let sorted=function(a,b){
//     let combine=[...a,...b];
//     let array=new Set(combine);
//     return array

// }
// let value=sorted(arr,arr2);
// console.log(value);
// ________________________________
// let arr=[{name:"pratik",score:20},{name:"mohit",score:22},{name:"hasmukh",score:19}];
// let names=arr.map((i)=>{
//     return i.name
// })
// console.log(names)

// let arr=[{name:"pratik",score:20},{name:"mohit",score:22},{name:"hasmukh",score:19}];
// let names=arr.filter((i)=>{
//     if(i.score>19){
//         return i.name
//     }
// })
// console.log(names)

// let arr=[{name:"pratik",score:20},{name:"mohit",score:22},{name:"hasmukh",score:19}];
// let sum=0
// let names=arr.reduce((acc,curr)=>{
//   sum= acc+curr.score
//     return sum;
// })
// console.log(names);

// let num=[1,2,3,4,5,6];
// let value=0;
// let sum=num.map((i)=> i*i).filter((s)=> s%2===0).reduce((acc,curr)=>{value=acc+curr
//     return value
// })
// console.log(sum)
// let arr=[{name:"pratik",score:20},{name:"mohit",score:22},{name:"hasmukh",score:19}];
// let name='';
// let value=arr.filter((i)=>i.score>19).map((s)=> s.name).reduce((acc,curr)=>{
//     name=acc+curr;
//     return name;
// })
// console.log(value)
// console.log(typeof value)
//  let arr=[{name:"pratik",score:20},{name:"mohit",score:22},{name:"hasmukh",score:19}];

// // let value=arr.filter((i)=>{return i.name!=="pratik"})
// // console.log(value)
// for (let i of arr){
//     if(i.name==="pratik"){
//         delete(i.name)
//     }
// }
// console.log(arr)

// let str="2+2"
// console.log(eval(str));


// let str="djjd";
// let str2="ejjdj";
// let sam=str.concat(str2)
// console.log(sam);

// const array1 = ['a', 'b', 'c'];
// const array2 = ['c','d', 'e', 'f'];
// const array3 = array1.concat(array2);

// console.log(array3);



// let value=arr.every((i)=>{
//   return i >30
// })

// console.log(value);

// const arrayLike = {
//     length: 3,
//     0: "a",
//     1: "b",
//     2: "c",
//     3: 345, // ignored by every() since length is 3
//   };

//   const value=Array.prototype.every.call

// let arr=[39,38,49,494,934];
// let v=arr.fill(4,4);
// console.log(v);
// console.log(arr);





