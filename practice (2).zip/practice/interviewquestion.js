// find max Number in array;

// let array=[1,3,50,5,2,8,9];
// let high=0;
// for(let i=0;i<array.length;i++){
//     if(array[i]>high){

//         high=array[i];

//     }

// }
//     console.log(high);

// Write a JavaScript program to reverse a given string

// let str="pratik";
// let reverse=str.split("").reverse().join();

// console.log(reverse);
// let temp=str[0]
// str[0]=str[5]
// temp=str[5]

// console.log();
// let a="";

// for(let i=str.length-1;i>=0;i--){

//  a+=str[i]

// }
// console.log(a);

// factorial number

// let num=Number(prompt("enter the value"));
// let num = 5;
// let sum = 1;
// for (let i = 1; i <= num; i++) {
//   sum *= i;
// }
// console.log(sum);

// triplet comprarison

function compareTriplets(a, b) {
  let alice = 0;
  let bob = 0;
  for (let i = 0; i < a.length; i++) {
    for (let j = i; j <= i; j++) {
      if (a[i] > b[i]) {
        alice++;
      } else if (a[i] === b[i]) {
        continue;
      } else if (a[i] < b[i]) {
        bob++;
      }
    }
  }
  return `${alice} ${bob}`;
}
let value = compareTriplets([5, 6, 7], [3, 6, 10]);
console.log(value);

// verybig sum

// function aVeryBigSum(ar) {
//   let sum=0
// for (let i=0;i<ar.length;i++){
//    sum+=ar[i];
// }
// return sum;
// }
// let value=aVeryBigSum([100001,100002,100003]);
// console.log(value);

// let arr=[1,2,3,4]
// let sum=0;
// for(let i=0;i<arr.length;i++){
//    sum+=arr[i]
// }
// console.log(sum);
