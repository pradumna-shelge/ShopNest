// const mainheading=document.getElementById("main-heading");
// console.log(mainheading);

// const mainheading = document.querySelector("#main-heading");
// const header = document.querySelector(".part1");
// const navItem = document.querySelectorAll(".nav-item");
// console.log(navItem);

// console.log(header);

// console.log(mainheading);

// change text----------------------textcontent and innertext

//  const mainheading = document.querySelector("#main-heading");

//   console.log(mainheading.textContent);
// console.log(mainheading.innerText);

//   mainheading.textContent="this is something new ";
//   console.log(mainheading.textContent);
  
//   change the style-----------------style
// const mainheading=document.querySelector("#main-heading");
// console.log(mainheading.style);
// mainheading.style.color="red";
// mainheading.style.border="20px solid black"


// get and set --------------------------

// const home=document.querySelector("a");
// console.log(home.getAttribute("href").slice(1));
// home.setAttribute("href","https://www.google.com/")
// console.log(home.getAttribute("href"));

// const formInput=document.querySelector(".signupform input");
// console.log(formInput.getAttribute("type"));

// get multiple elements using getElement by class name---------------------
// get multiple elements using querySelectorAll

// const navItem=document.getElementsByClassName("nav-item");
// console.log(navItem[1]);
// and its an array its give html collection
// const navItem=document.querySelectorAll(".nav-item");
// console.log(navItem);its give as a nodeList

// loop-------------------------
// let navItem=document.getElementsByTagName("a");
// we can not use for each in html collection
// simple for loop
// for of
// for each
// console.log(navItem);

// for (let i=0;i<navItem.length;i++){
//     navItem[i].style.backgroundColor="white";
//     navItem[i].style.color="red";   
//     navItem[i].style.fontWeight="bold";
// }
// navItem=Array.from(navItem);   html collection and node list to array
// console.log(Array.isArray(navItem));

// for (let i of navItem){
//     i.style.backgroundColor="white"
// }

// we can  use for each in node list
// simple for loop
// for of
// for each
// for (let i=0;i<navItem.length;i++){
//     navItem[i].style.backgroundColor="white";
//     navItem[i].style.color="red";   
//     navItem[i].style.fontWeight="bold";
// }

// innerHtml----------------------------------------

// const headline=document.querySelector(".headline");
// console.log(headline.innerHTML);
// headline.innerHTML="<h1>hii there </h1>";
// console.log(headline.innerHTML);
// headline.innerHTML+="<button class=\"btn\">log in</button>";

// console.log(headline.innerHTML);

// classList ,add and remove, toggle classes -----------------------

// const todo=document.querySelector(".part2");
// console.log(todo.classList);

// todo.classList.add("abc");

// todo.classList.remove('todos');


// const ans=todo.classList.contains("todos");
// console.log(ans);


// todo.classList.toggle("abc");
// todo.classList.toggle("abc");


// const part1=document.querySelector(".part1");
// // console.log(part1.classList);
// part1.classList.add("abc");
// // part1.classList.remove("abc");

// const ans=part1.classList.contains("abc");
// console.log(ans);

// part1.classList.toggle("abc");
// part1.classList.toggle("abc");


// Add HTML element using JavaScript-------------------

// const todolist=document.querySelector(".todo-list");
// todolist.innerHTML+="<li>yoo bro</li>";
// todolist.innerHTML+="<li>students</li>";


// createElement, append, prepend, remove, before, after ----------

// const newtodo=document.createElement("li");
// // const newtodotext=document.createTextNode("tech students");
// newtodo.textContent="students"
// const todolist=document.querySelector(".todo-list");
// // newtodo.append(newtodotext);
// // todolist.append(newtodo)
// todolist.prepend(newtodo)

// console.log(newtodo);


// const todolist=document.querySelector(".todo-list li");
// todolist.remove();



// const newtodo=document.createElement("li");
// newtodo.textContent="students" 
// const todolist=document.querySelector(".todo-list");
// todolist.before(newtodo)
 
// const newtodo=document.createElement("li");
// newtodo.textContent="students" 
// const todolist=document.querySelector(".todo-list");
// todolist.after(newtodo)


// insertAdjacentHTML-----------------------beforeend,beforbrgin,afterbegin,afterend;

// const todolist=document.querySelector(".todo-list");
// todolist.insertAdjacentHTML("afterend","<li>Second tofo</li>");

// Clone Nodes----------------------

// const ul=document.querySelector(".todo-list");
// const li=document.createElement("li");
// li.textContent="new todo";
// const li2=li.cloneNode()
// ul.append(li);
// ul.prepend(li);  


// appendChild, insertBefore, replaceChild, removeChild--------------------


// const ul=document.querySelector(".todo-list");
// // const li=document.createElement("li");
// const refrence=document.querySelector(".list-todo")
// // li.textContent="mew todo";
// // ul.insertBefore(li,refrence)

// const li=document.createElement("li");
// li.textContent="mew todo";

// // ul.replaceChild(li,refrence)
// ul.removeChild(refrence);

// static list vs live list---------------
// querySelector hame static list denge
// and getElementbysomthing hame live list denge

// const ul=document.querySelector(".todo-list");
// const listItem=ul.getElementsByTagName("li");
// const sixitem=document.createElement("li");
// sixitem.textContent="item 6";
// ul.append(sixitem);
// console.log(listItem);


// How to get the dimensions of an element--------- 
const part2=document.querySelector(".part2");
const info=part2.getBoundingClientRect();
console.log(info);
