// const headbtn=document.querySelector(".btn-headline");

// headbtn.onclick=function(){
//     console.log("hii");
    
// }
// function clickme(){
//     console.log("you click");
    
// }
// headbtn.addEventListener("click",function(){
//     console.log("you click");
    
// });

//  headbtn.addEventListener("click",()=>{
//     console.log("thanks");
    
//  })

// this-----------
// const headbtn=document.querySelector(".btn-headline");
// console.log(headbtn);


// headbtn.addEventListener=("click",()=>{
//     console.log("ddd");
    
//     console.log(this);
    
// })


// const btn=document.querySelectorAll(".my-button button");
// for(let button of btn){
//     button.addEventListener("click",function(){
//         console.log(this.textContent);
        
//     })
// }
// btn.forEach(function(button){
//     button.addEventListener("click",function(){
//                 console.log(this.textContent);
                
//             })
// })


// // event object---------------

// const fbutton=document.querySelectorAll(".my-button button");
// for(let i of fbutton){
//     i.addEventListener("click",function(){
//     console.log(this);
    

    
//     })
// }

// const allButton=document.querySelectorAll(".my-button button");
// allButton.forEach((button)=>{
//     button.addEventListener("click",(e)=>{
//        e.target.style.color="red";
//        e.target.style.backgroundColor="yellow";
        
//     })
// })

// background colorchange-----------------------------


// const allButton=document.querySelectorAll(".my-button button");
// const body=document.body;
// function randomcolorGenerator(){
//     const red=Math.floor(Math.random()*255);
//     const green=Math.floor(Math.random()*255);
//     const blue=Math.floor(Math.random()*255);
//     const random=`rgb(${red},${green},${blue})`;
//     return random;

// }
// allButton.forEach((button)=> {
//     button.addEventListener("click",(e)=>{
//         const randomColor=randomcolorGenerator();
//         body.style.backgroundColor=randomColor;
//          e.target.style.color=randomColor;
//       })
// });
 


// keypress event--- and mouseover event----------------

// const body=document.body;
// body.addEventListener("keypress",(e)=>{
//     console.log(e);
    
// })
// const button=document.querySelector(".btn");
// button.addEventListener("mouseover",()=>{
//     console.log("mouser over");
    
// })

// button.addEventListener("mouseleave",()=>{
//     console.log("mouser leave");
    
// })

// event bubbling/propogation-----event capturing---event delegation

   