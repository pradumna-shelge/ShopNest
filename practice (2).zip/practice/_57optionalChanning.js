const user={
    firstName:"pratik",
    address:{houseover:"latur"}
}
console.log(user?.address?.houseover);

// ?: use for ager hai to value dedo nahi to undefined ayge


