let num=19;
let useraGuess= Number(prompt("guess a number"))


if(num===useraGuess){
    console.log("guess id correct");
}
else if(num>useraGuess){
   console.log("guess is low");
   
}
else if(num<useraGuess){
    console.log("guess in high");
    
}
else{
    console.log("oops");
    
}