const band={
    bandName:"boci",
    song:"ssois",
    year:1968
}
console.log(band);

const{bandName,song,year}=band;
console.log(bandName);

