let arr=[{name:"pratik",pay:233321},{name:"sham",pay:2000},{name:"ram",pay:2000}];

// const arr2=arr.filter((i)=>i.pay>20000);
// console.log(arr2);

// const arr2=arr.reduce((acc,curr)=>{
//     return acc+curr.pay
// },0)
// console.log(arr2);


// const arr2=arr.find((i)=>{
//     if(i.name==="pratik"){
//         i.name="ram";
//     }
//     return i;
// })

// console.log(arr2);

// const arr2=arr.some((i)=>i.name==="pratik")
// console.log(arr2);

// const arr2=new Set([1,1,2,3,4,4])
// console.log(arr2);


// string

// Palindrome Check:
// Write a function isPalindrome that checks whether a given string is a palindrome (reads the same forwards and backwards).

let str="sahas";

function palindrome(a){
    let str2=str.split("").reverse().join("");
    if(a===str2){
        console.log("true");

    }
    else{
        console.log("false");

    }
} 
palindrome(str);


