console.log(num);
var num=[1,23,3]
console.log(num);
