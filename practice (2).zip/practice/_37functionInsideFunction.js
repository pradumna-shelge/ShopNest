 function multipleFun(){
    const sum=()=>console.log("hee");

    const add=(num1,num2)=>{
        return num1 *num2
    }
    sum();
    console.log(add(2,3));
     
    console.log("welcome");
    

 }
 multipleFun();