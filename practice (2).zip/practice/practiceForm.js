/* <div class="part3">
<h2>Sign up</h2>
<form class="signupform">
  <div class="group">
    <label for="username">username</label>
    <input type="text" name="username" id="username">
  </div>
  <div class="group">
    <label for="password">password</label>
    <input type="password" name="password" id="password">
  </div>
  <div class="group">
    <label for="confirmPassword">confirmPassword</label>
    <input type="password" name="confirmPassword" id="confirmPassword">
  </div>
  <div class="group">
    <label for="email">phone</label>
    <input type="email" name="email" id="email">
  </div>
  <div class="group">
    <label for="about">about us</label>
    <textarea name="about" id="about" cols="30" rows="10"></textarea>
  </div>
  <button type="submit" class="btn">submit</button>
</form> */


const form =document.querySelector(".signupform");
const username=document.querySelector(".group input[type='text']");
const password=document.querySelector(".group input[type='password']");
const print=document.querySelector(".get-data")





form.addEventListener("submit",(e)=>{
    e.preventDefault();
    // console.log(`name:${username.value}password:${password.value}`);
    let data=`name:${username.value}`
    print.value=`${data}`
    
    
})