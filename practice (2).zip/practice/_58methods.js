// methods

// function inside object

// const person={
//     firstName:"rahul",
//     age:20,
//     about:function(){
//         console.log(`my name is ${this.firstName} and my age is ${this.age}`);
        
//     }
// }
// person.about();

// this keyword define whole object{const person={
//     firstName:"rahul",
//     age:20,
//     about:function(){
//         console.log(`my name is ${this.firstName} and my age is ${this.age}`);
        
//     }}


// function perfect(){
//     console.log(`my name is ${this.firstName} and age is ${this.age}`);
    
// }

// const person1={
//     firstName:"pratik",
//     age:22,
//     about:perfect
// }
// const person2={
//     firstName:"sham",
//     age:23,
//     about:perfect
// }
// const person3={
//     firstName:"Pradip",
//     age:24,
//     about:perfect
// }

// person1.about();
// person2.about();
// person3.about();

// question :
// console.log(this)//its prints the window object and this===window ,so for that use strict mode