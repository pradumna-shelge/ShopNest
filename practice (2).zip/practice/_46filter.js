   const arr=[2,4,5,6,3,7];

//    const iseven=arr.filter((num)=>{
//           return num%2===0;
//    })
//    console.log(iseven);
   const odd=arr.filter((a)=>a%2==1);
   console.log(odd);
   