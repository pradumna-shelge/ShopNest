// data(1,2);

// function data(a,b){
//     console.log(a+b);
    
// }

// a=10;
// console.log(a);
// var a;



"use strict"
a=10;
var a;


// "use strict";
// x = 3.14;