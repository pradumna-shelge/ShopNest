const userMethod={
    about:function() {
        return `${this.firstName}and ${this.lastNAme}`
     },
     is18:function (){
        return this.age>=18;
     }

}

 function createUser(firstName,lastNAme,email,age,address){
    const user={};
    user.firstName=firstName;
    user.lastNAme=lastNAme;
    user.email=email;
    user.age=age;
    user.address=address;
    user.about=userMethod.about;
    user.is18=userMethod.is18; 
    return user;

 }
 
 const value=createUser("pratik","shelage","Pratik@gmail.com",22,"latur");
//  console.log(value);
//  const is18=value.is18();
//  console.log(is18);
const value1=createUser("sham","shelage","Pratik@gmail.com",22,"latur");
const value2=createUser("ram","shelage","Pratik@gmail.com",22,"latur");
const value3=createUser("bob","shelage","Pratik@gmail.com",22,"latur");

console.log(value.about());
console.log(value1.is18());
