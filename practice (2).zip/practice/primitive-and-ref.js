// premitive

let num1=6;
let num2=num1;
console.log(num1);
console.log(num2);
num1++;
console.log(num1);
console.log(num2); 

let arr=["mango","banana","apple"]
let arr2=arr;
console.log(arr);
console.log(arr2);
arr.pop();
console.log(arr);
console.log(arr2);



