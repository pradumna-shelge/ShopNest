let fristName = "pratik";
console.log(fristName[3]);

console.log(fristName.length);

console.log(fristName[fristName.length - 1]);
