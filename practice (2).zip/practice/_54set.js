// const value=new Set([1,2,3,4,5]);
// console.log(value);

// value.add(6);
// console.log(value);


// let arr=["pratik","doly","sham"];
// value.add(arr)
// console.log(value);

// if(value.has(1)){
//     console.log("true");
    
// }
// else{
//     console.log(false);
    
// }

// for(let i of value){
//     console.log(i);
    
// }

// let arr=["pratik","doly","sham","sham"];
//  const unique=new Set(arr);
//  console.log(unique);
 
 let arr=[2,2,2,2];

 function sum(b){
    let a=new Set(b);
    let c=toString(a)
   
 }
 console.log(sum(arr));
 