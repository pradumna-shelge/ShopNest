

console.log("hello world");