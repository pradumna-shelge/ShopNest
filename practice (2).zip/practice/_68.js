// class react{
//     constructor(name,age){
//         this.name=name;
//         this.age=age;
//     }
// }

// let data=new react("pratik",32);
// console.log(data);

// let value=class value2{
//         constructor(name,age){
//             this.name=name;
//             this.age=age;
//         }
//     }

//     let data=new value("pratik",32);
//     console.log(data);

// let value=class{
//         constructor(name,age){
//             this.name=name;
//             this.age=age;
//         }
//     }

//     let data=new value("pratik",32);
//     console.log(data);

// let value=class value2{
//         constructor(name,age){
//             this.name=name;
//             this.age=age;
//         }
//        get is18(){
//             return this.age>18?"you come":"you not"
//         }
//        get names(){
//             return `your name is ${this.name}`
//         }
//         set names(names){
//             this.names=names;
//         }
//     }

//     let data=new value("pratik",32);
//     console.log(data.names);

// let obj = [
//   {
//     name: "pratik",
//     age: 28,
//   },
//   { name: "rahul", age: 22 },
//   { name: "om", age: 23 },
// ];

// for(let i of obj)
// {
//     if(i.name=="rahul"){
//         delete(i)
//     }
// }
// console.log(obj);
// let value=obj.filter((i)=>i.age>22)
// console.log(value);
