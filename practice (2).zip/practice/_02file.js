"use strict"

var firstName="Harshit";
console.log(firstName);

firstName="pratik";
console.log(firstName);

var value1=10;
console.log(value1 *0.5);

