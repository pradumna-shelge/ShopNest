// iterate obj
const person = { name: "pratik", age: 22 ,hobbies:["cricket","vollyboll"]};
person.hobbies.pop();
console.log(person);


for(let key in person){
    console.log(`${key} : ${person[key ]}`);
    
}