const obj={
    key1:"value1",
    key2:"value2"
}

const obj2=Object.assign({},obj)
console.log(obj2);


