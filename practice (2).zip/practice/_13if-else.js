let age=18;
if(age>=18){
    console.log("you vcane play the game");
    
}
else{
    console.log("usr can play mario");
    
}

let num=12;

if(num%2===0){
    console.log("even");
    
}else{
    console.log("odd");
    
}