let fruits=["apple","mango","banana","grapes"];
let array=[];
for(let item of fruits){
    array.push(item);
    
}
console.log(array);
