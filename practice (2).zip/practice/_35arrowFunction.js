const sum=(a,b)=>a*b;

console.log(sum(2,4));
