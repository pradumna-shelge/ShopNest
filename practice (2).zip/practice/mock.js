// primitive
// Number
// String
// undefined
// Boolean
// null
// BigInt
// Symbol


// non-primitive
// object 
// array


// function ani(callback) {
//     console.log("hiii");
//     callback();
// }

// function cat(){
// console.log("there")
// }

// ani(cat)


// let car = {
//     make: "Toyota",
//     model: "Corolla",
//     year: 2021
// };

// car.branname="nisan";
// console.log(car);

// car.year=2024;
// console.log(car);

// Write a JavaScript program to list the properties of a JavaScript object.

// Sample object
// :

// var student = {

// name : "David Rayy",

// sclass : "VI",

// rollno : 12 };

// // Sample Output
// // : name,sclass,rollno

// for (let key in student){
//     console.log(student[key]);
    
// }

// Write a JavaScript program to delete the rollno property from the following object. Also print the object before or after deleting the property.

// Sample object
// :

// var student = {

// name : "David Rayy",

// sclass : "VI",

// rollno : 12 };

// console.log(student);
// delete(student.rollno)
// console.log(student);

// Write a JavaScript program to display the reading status (i.e. display book name, author name and reading status) of the following books.
// var library = [ 
//    {
//        author: 'Bill Gates',
//        title: 'The Road Ahead',
//        readingStatus: true
//    },
//    {
//        author: 'Steve Jobs',
//        title: 'Walter Isaacson',
//        readingStatus: true
//    },
//    {
//        author: 'Suzanne Collins',
//        title:  'Mockingjay: The Final Book of The Hunger Games', 
//        readingStatus: false
//    }];

//    for (let item of library){
//       console.log(item.readingStatus);
//    }

// types of function js
// 1=named function
// 2.anonimous function
// 3.arrow function
// 4.callback function
// 5.imidiate invoke function


// function fact(num){
//     let sum=1;
//     for(let i =1;i<=num;i++){
//       sum*=i;
//     }
//     return sum;
// }
// console.log(fact(5));



// let arr=[1,2,3];

// function add([item1,item2,item3]){
// console.log(item1);
// console.log(item2);

// console.log(item3);


// }
// add(arr)