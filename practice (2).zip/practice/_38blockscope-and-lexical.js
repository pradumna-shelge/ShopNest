// function myapp(){
//     if(true){
//         let name="harhit";
//         console.log(name);  
//     }
//     console.log(name);
    
// }
// myapp();


{
    let name="harshit"
}
console.log(name);

{
    var name="ram"

}
console.log(name);
