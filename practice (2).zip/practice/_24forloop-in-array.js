let fruits=["apple","mango","banana","grapes"];
let arr=[]
for(let i=0;i<=fruits.length-1;i++){
   arr.push(fruits[i]);
    
}
console.log(arr);
