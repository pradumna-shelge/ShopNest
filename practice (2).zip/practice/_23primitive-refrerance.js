  let num1=4;
  let num2=num1;
  console.log(num1);
  console.log(num2);
  num1++;
  console.log(num1);
  console.log(num2);



//   ref

let arr=[1,2,3,4,5]
let array=arr;

console.log(arr);
console.log(array);
arr.push(8);
console.log(arr);
console.log(array);



  
  