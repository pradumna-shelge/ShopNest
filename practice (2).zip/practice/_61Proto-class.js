// const user={
//     firstName:"harshit",
//     lastNAme:"reddy",
//     email:"Pratik@gmail.com",
//     age:22,
//     address:"latur",
//     about(){
//         return `${this.firstName} is ${this.age} year old`
//     },
//     is18(){
//         return this.age>=18;
//     }
// } 

// function create object
// add key value pair in in
// object ko return karega

// function createUser(firstName,lastNAme,email,age,address){
//          const user={};
//          user.firstName=firstName;
//          user.lastNAme=lastNAme;
//          user.email=email;
//          user.age=age;
//          user.address=address;
//          user.about=function(){
//             return `${this.firstName}and ${this.lastNAme}`
//          }
//          user.is18=function(){
//             return this.age>=18;
//          }
//          return user;
// }

// const value=createUser("pratik","shelage","Pratik@gmail.com",22,"latur");
// console.log(value);
// const is18=value.is18();
// console.log(is18);


// create a function create multiple object

