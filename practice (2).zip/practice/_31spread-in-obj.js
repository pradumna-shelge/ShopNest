const obj1={
    key1:"value",
    key2:"value2"
}
const obj2={
    key3:"value",
    key2:"value2"
}
const obj3={...obj1  ,...obj2,key6:"vajaj"}
console.log(obj3);
