let age=22;
let name="pratik";

// console.log(`my name is ${name} and my age is ${age}`);

let join=`my name is ${name} my age is ${age}`;
console.log(join);
