const grandfather=document.querySelector(".grandfather");
// const father=document.querySelector(".father");
// const child=document.querySelector(".child");

// child.addEventListener("click",()=>{
//     console.log("you clicked !!!!!!!! on child");
    
// },true)
// father.addEventListener("click",()=>{
//     console.log("you clicked !!!!!!!!!! on father");
    
// },true)
// grandfather.addEventListener("click",()=>{
//     console.log("you clicked !!!!!!!!!! on grandfather");
    
// },true)
// document.body.addEventListener("click",()=>{
//     console.log("you clicked !!!!!!!!!!!!! on body");
    
// },true) 






// child.addEventListener("click",()=>{
//     console.log("you clicked on child");
    
// })
// father.addEventListener("click",()=>{
//     console.log("you clicked on father");
    
// })
// grandfather.addEventListener("click",()=>{
//     console.log("you clicked on grandfather");
    
// })
// document.body.addEventListener("click",()=>{
//     console.log("you clicked on body");
    
// }) 




// event delegation----------

// grandfather.addEventListener("click",(e)=>{
//     console.log(e.target);
    
// })