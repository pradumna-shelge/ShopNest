 const myarr=[ "item1","item2","item3 "];

 myarr.splice(1,1);
 console.log(myarr);
 