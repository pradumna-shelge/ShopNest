   for (let k = 1; k <=i; k++) {
        //     process.stdout.write("*");
        //    }