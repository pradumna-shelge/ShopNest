const key1 = "obj1";
const key2 = "obj2";

const value1 = "myVale1";
const value2 = "muValue2";

// const obj = {[key1]:value1,
// [key2]:value2
// };
// console.log(obj);

const obj = {};
obj[key1]=value1;
obj[key2]=value2;
console.log(obj);
