const number=[1,2,3,4,5]

// let sum=number.reduce((accumulator,current) => {
//     return accumulator+current
// },1000);
// console.log(sum);
const num=number.reduce((acc,curr)=>{
    return acc+curr
})
console.log(num);
