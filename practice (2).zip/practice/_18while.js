// let i =0;
// while(i<=10){
//     console.log(i);
//     i++;
// }

// let num=10;
// let sum=0;
// let i=0;
// while(i<=100){
//      sum=sum+i;
//      i++;
// }
// console.log(sum);

// let char="";
for(let i=1; i<=4;i++){
     for(let j=1;j<=i;j++){
          char=char+("*")
     }
     console.log(char);

     char="";
}
// var a = [2, 3, 3];
// console.log(a.join(""));

// let space="";
// let char="";

// for(let i=1;i<=4;i++){
//      for(let j=4-i;j>i;j--){
//           space+=" ";

//           for(let k=1;k<=i;k++){
//                char+="*"
//           }
//           console.log(space);

//           console.log(char);
//           space=""
//           char=""

//      }
// }

for(let i=1; i<=4;i++){
     for(let j=1;j<=i;j++){
         console.log("*");
         
     }
     console.log("\n") ;
}



