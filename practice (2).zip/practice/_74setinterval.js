// console.log("hii there");
// setInterval(()=>{
//     let red=Math.floor(Math.random()*125)
//     let green=Math.floor(Math.random()*125)
//     let blue=Math.floor(Math.random()*125)
//     let rgb=`rgb(${red},${green},${blue})`
//     body.style.background=rgb
// },1000)

// const heading1 = document.querySelector(".Heading1");
// const heading2 = document.querySelector(".Heading2");
// const heading3 = document.querySelector(".Heading3");
// const heading4 = document.querySelector(".Heading4");
// // callback hell
// setInterval(() => {
//   heading1.textContent = "one";
//   heading1.style.color = "red";
//   setInterval(() => {
//     heading2.textContent = "two";
//     heading2.style.color = "pink";
//     setInterval(() => {
//       heading3.textContent = "three";
//       heading3.style.color = "yellow";
//       setInterval(() => {
//         heading4.textContent = "four";
//         heading4.style.color = "blue";
//       }, 4000);
//     }, 3000);
//   }, 2000);
// }, 1000);

// function changetext( element,text,color,time){
//     setTimeout(()=>{
//         element.textContent=text;
//         element.style.color=color
//     })
// }
// changetext(heading,"one","red",1000)



// async and await


const url = "https://jsonplaceholder.typicode.com/posts";

async function getdata(){
     const response=await fetch(url);
     console.log(response   );
     
}

getdata();
