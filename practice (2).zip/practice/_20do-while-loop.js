let i=11;

do{
    
console.log(i)
i++;    
    
}while(i<=10);
