{
  /* <div class="part2 todos">
  <h2>your plan for today?</h2>
  <form class="form">
    <input type="text" name="" id="" placeholder="Add todo ">
    <input type="submit" value="Add todo" class="btn">
  </form>
  <ul class="todo-list">
<li>
  <span class="text">Do this</span>
  <div class="todo-button">
    <button class="todo-btn done">done</button>
    <button class="todo-btn remove">remove</button>
  </div>
</li>   
  </ul>
</div> */
}

// const form = document.querySelector(".form");
// const input = document.querySelector(".form input[type='text']");
// const ul=document.querySelector(".todo-list")

// form.addEventListener("submit", (e) => {
//   e.preventDefault();
//   const newTodo = input.value;
//   const newli = document.createElement("li");
//   const newliInnerhtml = `
//   <span class="text">${newTodo}</span>
//   <div class="todo-button">
//     <button class="todo-btn done">done</button>
//     <button class="todo-btn remove">remove</button>
//   </div>
//  `;
// newli.innerHTML=newliInnerhtml;
// ul.append(newli)
//   input.value = "";
// });

// ul.addEventListener("click",(e)=>{
//     if(e.target.classList.contains("remove")){
//            const targetli=e.target.parentNode.parentNode;
//            targetli.remove();
        
//     }
//     if(e.target.classList.contains("done")){
//   const lispan=e.target.parentNode.previousElementSibling      
// lispan.style.textDecoration="line-through"  
//     }
// })