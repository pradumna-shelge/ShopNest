
let obj=[
    {name:"pratik",age:20},{name:"om",age:22},{name:"sham",gender:"male"}
]

// let array=obj.filter((i)=>{
//       return i.name!=="om";
// })
// console.log(array);


// let array=function(obj){
//     return obj.name!=="om";

// }
// console.log(obj.filter(array));

// let [obj1,obj2,obj3]=obj;
// console.log(obj1);

// let [{name:no},,{gender}]=obj;
// console.log(no);
// console.log(gender);





// let num=33;
// let sum=(num).toString();
// console.log(typeof sum);

