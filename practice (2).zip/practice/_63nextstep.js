const obj1={
    key:"value1",
    key2:"value2"
}

const obj2=Object.create(obj1);
obj2.key="value2;"
console.log(obj2);
// proto get the value form another object


