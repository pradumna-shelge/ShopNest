// Array push and pop
// let array=["mango","banana","graps"];
// let Popped=array.pop();
// console.log(array);
// console.log("popped fruit is:"+ Popped);


// array.push("apple")

// console.log(array);

// Array shift unshift
let array=["mango","banana","graps"];

array.unshift("fruits");
console.log(array)

let remove=array.shift();
console.log(array) ;
