// const person={
//     name:"harsh",
//     gender:"male"
// }
// function getDetails(obj){
//  console.log(obj.name);
//  console.log(obj.gender);
// }
// function getDetails({name,gender}){
//     console.log(name);
//     console.log(gender);
//    }

// getDetails(person);


