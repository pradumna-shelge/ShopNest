let arr=[1,2,3,4,5,67];

 arr.fill(9,2,5);
//  Value,start,end
console.log(arr);
