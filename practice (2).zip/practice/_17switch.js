let day = 1;

switch (day) {
  case 0:
    console.log("monday");
    break;
  case 1:
    console.log("trsuesday");
    break;
  case 3:
    console.log("wensday");
    break;
  case 4:
    console.log("thursday");
  case 5:
    console.log("friday");
    break;
  case 6:
    console.log("saturday");
    break;
  case 7:
    console.log("sunday");
    break;
  default:
    console.log("nothing");
};

