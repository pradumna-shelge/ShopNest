let string1="12";
let string2="12";

let fullName=Number(string1) + Number(string2);
console.log( fullName);
