// for(let i=0;i<=9;i++){
//     console.log(i)
// }

let total=0;
let num=100;
for (let i = 0; i <=num; i++) {
    total+=i;
    
}
console.log(total);
