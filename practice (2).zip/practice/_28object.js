// const person = { name: "pratik", age: 22 };
// console.log(typeof person);
// console.log(person.name);

// const person = { name: "pratik", age: 22 ,hobbies:["cricket","vollyboll"]};
// delete(person.name);
// console.log(person);



// console.log(person.hobbies.push("rsm"));
// console.log(person);
// person.gender="male";
// console.log(person);

const key="mail"
const person = { name: "pratik", age: 22 , hobbies:["cricket","vollyboll"]};
console.log(person.hobbies);

person[key]="prat@g,ail.com"
console.log(person);
