// function myfuction(a,b,...c){
//     console.log(a);
//     console.log(b);
//     console.log(c);    
// }
// myfuction(3,4,6,4,5,6,7);
let sum=0;
 function add(...num){
    console.log(num);
    console.log(Array.isArray(num));
    for(let item of num){
       sum +=item
    }
    console.log(sum);
    
    
    
 }
 add(1,2,34,5)
