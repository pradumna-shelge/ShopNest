let name;
console.log(typeof name);
name="pratik"
console.log(typeof name ,name);

let myVar=null;
console.log(typeof myVar);


let mynumber= 123n;
console.log(typeof mynumber,mynumber);

