// ordered list in array

// let arr=["mango","pineapple","dis"]
// console.log(arr[0]);
let num=[1,2,3,4,5,6];
// console.log(num);

num[2]=6;
console.log(num);

console.log(typeof num);
console.log(Array.isArray(num));



